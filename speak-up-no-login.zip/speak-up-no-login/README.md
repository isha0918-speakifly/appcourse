# Speak Up — no-login version

Same English speaking course — level-based lessons, vocabulary practice,
and an AI speaking partner — but with **no accounts, no passwords, no login
screen**. Each student's progress is remembered automatically on their own
device.

## How "remembering progress without login" works

There's no database of students. Instead, the first time a student opens
the link, the site creates a small progress record and saves it in their
**browser's local storage** (`js/progress.js`). Every time they come back
on that same device/browser, the site reads that record and puts them back
exactly where they left off — same level, same completed units.

- ✅ Leaves and comes back later on the same phone/laptop → same progress
- ✅ You can give every student the same link, or personalize it with
  `?student=Riya` so the site greets them by name
- ⚠️ Switches to a different device, or clears browser data → progress resets,
  since nothing is stored on a server. If you outgrow this, the easy upgrade
  path is swapping `js/progress.js` for a version backed by a database — say
  the word and it can be added later.

## What's inside

```
index.html                levels dashboard (this is the homepage now)
lesson.html                 units, vocabulary, pronunciation practice
speaking-partner.html      voice conversation with the AI
css/styles.css               all styling
data/curriculum.js           lesson content — edit to add levels/units/words
js/progress.js                saves/reads progress in localStorage
js/speech.js                   browser speech-to-text and text-to-speech
js/ai-partner.js               talks to the Cloud Function proxy below
functions/index.js            server-side proxy that calls the Claude API
```

## Step-by-step setup

### 1. Get the code onto GitHub
```
git init
git add .
git commit -m "Speak Up course site (no login)"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/speak-up.git
git push -u origin main
```

### 2. Turn on GitHub Pages
In your repo: **Settings → Pages → Source: Deploy from branch → main → / (root) → Save**.
After a minute, your site is live at:
```
https://YOUR_USERNAME.github.io/speak-up/
```
That link (optionally with `?student=Name` added) is what you send students.
Nothing else is required for the lessons and vocabulary to work.

### 3. Set up the AI speaking partner (one-time)
The AI partner needs a tiny backend so your Claude API key stays private —
it can't live in the website's code, since anyone could view it there.

1. Get an API key at console.anthropic.com.
2. Create a free Firebase project at console.firebase.google.com (you only
   need this for the one Cloud Function — no Authentication or Firestore
   setup needed).
   - Note: deploying a Cloud Function that calls an external API requires
     switching the project to the "Blaze" (pay-as-you-go) plan. You still
     stay within the free monthly quota for normal classroom use; you just
     need a card on file.
3. Install the CLI and deploy:
   ```
   npm install -g firebase-tools
   firebase login
   firebase init functions      # choose JavaScript; don't overwrite functions/index.js
   cd functions && npm install
   firebase functions:config:set anthropic.key="YOUR_ANTHROPIC_API_KEY"
   cd ..
   firebase deploy --only functions
   ```
4. Copy the URL it prints, e.g.
   `https://us-central1-yourproject.cloudfunctions.net/chatWithPartner`,
   and paste it into `CLOUD_FUNCTION_URL` at the top of `js/ai-partner.js`.
5. Commit and push that one-line change:
   ```
   git add js/ai-partner.js
   git commit -m "Connect AI speaking partner"
   git push
   ```

### 4. Try it
Open your GitHub Pages link, pick Level 0, work through a unit, then tap
"Practice with the AI speaking partner" and use the microphone button.
The mic needs HTTPS, which GitHub Pages already provides.

## Sharing links with students

- Same link for everyone: `https://YOUR_USERNAME.github.io/speak-up/`
- Personalized greeting: `https://YOUR_USERNAME.github.io/speak-up/?student=Riya`
  (only affects the "Welcome back" text — progress still lives on their device)

## Extending the course

Add levels, units, and words in `data/curriculum.js` — plain JavaScript
objects, no other file needs to change.

## Known limitations

- Progress is per-device, not per-student-across-devices (see above).
- Pronunciation scoring in `speech.js` is simple word-matching, not
  phoneme-level accuracy.
- Voice input/output works best in Chrome or Edge; Safari support is partial.
